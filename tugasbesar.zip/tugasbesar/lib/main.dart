import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Alert',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: _HomePageWidgetState(),
    );
  }
}

class _HomePageWidgetState extends StatelessWidget {
  int _selectedNavbar = 0;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: AppBar(
        toolbarHeight: 50,
        backgroundColor: Colors.blue[500],
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: true,
        leading: Icon(
          Icons.dehaze_outlined,
          color: Colors.black,
          size: 24,
        ),
        title: Text(
          'Landslide Panic Button App',
          style: TextStyle(color: Colors.black),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(children: [
              Expanded(
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        shape: CircleBorder(), primary: Colors.red),
                    child: Container(
                      width: 200,
                      height: 200,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(shape: BoxShape.circle),
                      child: Text(
                        'PRESS!!',
                        style: TextStyle(fontSize: 24),
                      ),
                    ),
                    onPressed: () {
                      _showDialog(context);
                    }),
              )
            ]),
            Padding(padding: EdgeInsets.only(top: 16)),
            Text('Tekan Tombol Di Atas Jika Terjadi Longsor!')
          ]),
      bottomNavigationBar: BottomNavigationBar(
        iconSize: 40,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'Document',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.lightbulb),
            label: 'Tentang Longsor',
          ),
        ],
        currentIndex: _selectedNavbar,
        selectedItemColor: Colors.blue[500],
        unselectedItemColor: Colors.grey,
      ),
      backgroundColor: Color(0xFFF5F5F5),
    ));
  }
}

void _showDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: new Text("LAPORAN DITERIMA!"),
        content: new Text("Mengirimkan pesan ke pengguna sekitar anda.."),
        actions: <Widget>[
          new FlatButton(
            child: new Text("OK"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}
